import os

class Config:
    SQLALCHEMY_DATABASE_URI = 'sqlite:///site.db'  # پایگاه داده SQLite
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = os.urandom(32)  # کلید امنیتی
